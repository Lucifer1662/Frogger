package FroggerGame.Frog;

import org.newdawn.slick.geom.Vector2f;

public interface ControlableMovement {
	public Vector2f GetMovenent();
}
