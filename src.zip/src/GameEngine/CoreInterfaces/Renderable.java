package GameEngine.CoreInterfaces;

public interface Renderable {
	void render();
}
