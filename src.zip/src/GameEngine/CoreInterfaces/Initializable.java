package GameEngine.CoreInterfaces;

public interface Initializable {
	public void init();
}
