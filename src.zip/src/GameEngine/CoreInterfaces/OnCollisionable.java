package GameEngine.CoreInterfaces;

import GameEngine.Components.Collider;

public interface OnCollisionable {
	public void onCollision(Collider collider);
}
