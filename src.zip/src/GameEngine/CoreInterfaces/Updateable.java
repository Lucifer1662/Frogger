package GameEngine.CoreInterfaces;

public interface Updateable {
	void update();
}
